"""Main method for RedditGildedComments.
Project by:
Joanne Kim
Rebecca Mahany
"""

import sys
import csv

from statistics import mean
import datetime

import analyze_language as al
from tests import test_analyze_language as t_al

import scoreandlen
import score_test
#not checking len


import pdb

def run_program():

	# Make graphs (Joanne)
	tup = scoreandlen.datagrab()
	scores = tup[0]
	subredditavg = tup[1]
	scoreandlen.allscores(scores)
	scoreandlen.subredditaverage(subredditavg)
	object = score_test.AnalyzeScoreTest()
	object.GeneralScoreTest()
	object.SubredditScoreTest()



def main():

	# Parse command line args
	debug = False
	run = False
	if len(sys.argv) == 2:
		
		if sys.argv[1] == "help":
			print("To run, please enter \"python3 main.py\"! No args needed.") #TODO Please change this if we need command line args down the line!
			print("If you're having difficulties, you may need to enter \"nltk.download()\" first.")
		
		if sys.argv[1] == "run_tests":
			# Run tests for analyze_language.py (Rebecca)
			test = t_al.AnalyzeLanguageTest()
			test.ALTest()
			test.RATest()
			test.WordInfoTest()
			test.SentInfoTest()
			test.ParagInfoTest()
			test.ContentInfoTest()
			test.SentimentInfoTest()
			test.POSTest()

		if sys.argv[1] == "debug":
			print("Running in debug:")
			debug = True
			run = True

	if len(sys.argv) == 1:
		run = True

	if run:
		
		if debug:
			pdb.run("run_program()")
		else:
			run_program()


if __name__ == '__main__':
	main()
